// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    // Carregar lista de alunos ao carregar a página
    carregarAlunos();

    // Evento de clique para exibir o formulário de cadastro
    document.getElementById('btn-novo-aluno').addEventListener('click', function() {
        exibirFormulario();
    });

    // Evento de clique para submeter o formulário de cadastro
    document.getElementById('form-cadastro').addEventListener('submit', function(event) {
        event.preventDefault();
        cadastrarAluno();
    });
});

function carregarAlunos() {
    // Simulação de dados de alunos
    const alunos = [
        { nome: 'João', email: 'joao@example.com' },
        { nome: 'Maria', email: 'maria@example.com' }
    ];

    // Limpar lista de alunos
    document.getElementById('alunos-lista').innerHTML = '';

    // Adicionar alunos à lista
    alunos.forEach(function(aluno) {
        const alunoHTML = `<div class="card">
                            <div class="card-body">
                                <h5 class="card-title">${aluno.nome}</h5>
                                <p class="card-text">${aluno.email}</p>
                            </div>
                        </div>`;
        document.getElementById('alunos-lista').innerHTML += alunoHTML;
    });
}

function exibirFormulario() {
    // Exibir o formulário de cadastro e ocultar a lista de alunos
    document.getElementById('cadastro-form').style.display = 'block';
    document.getElementById('alunos-lista').style.display = 'none';
}

function cadastrarAluno() {
    // Simulação de cadastro de aluno
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;

    // Aqui você fará uma requisição AJAX para enviar os dados do formulário de cadastro para o servidor PHP
    console.log('Aluno cadastrado:', nome, email);

    // Voltar para a lista de alunos após o cadastro
    document.getElementById('cadastro-form').style.display = 'none';
    document.getElementById('alunos-lista').style.display = 'block';
    carregarAlunos(); // Atualizar a lista de alunos
}