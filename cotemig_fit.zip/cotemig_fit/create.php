<!DOCTYPE html>
<?php
require ('conexao.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {  $nome = $_POST["nome"] . 
                                    '<br>';  $email = $_POST["email"] .
                                    '<br>';  $endereco = $_POST["endereco"] .
                                    '<br>';  $sexo = $_POST["sexo"] .
                                    '<br>';  $numero = $_POST["numero"] .
                                    '<br>';  $modalidade = $_POST["modalidade"] .
                                    '<br>';  $bairro = $_POST["bairro"] .
                                    '<br>';  $cidade = $_POST["cidade"] .
                                    '<br>';  $uf = $_POST["uf"] .
                                    '<br>';  $complemento = $_POST["complemento"];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dados do Formulário</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
            margin-bottom: 50px;
            background-color: white;
            color: black;
            border-radius: 10px;
            padding: 20px;
        }

        .table th,
        .table td {
            color: black;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Dados do Formulário</h1>
        <table class="table">
            <tbody>
                <tr>
                    <th>Nome</th>
                    <td><?php echo $nome; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $email; ?></td>
                </tr>
                <tr>
                    <th>Endereço</th>
                    <td><?php echo $endereco; ?></td>
                </tr>
                <tr>
                    <th>Sexo</th>
                    <td><?php echo $sexo; ?></td>
                </tr>
                <tr>
                    <th>Número</th>
                    <td><?php echo $numero; ?></td>
                </tr>
                <tr>
                    <th>Modalidade</th>
                    <td><?php echo $modalidade; ?></td>
                </tr>
                <tr>
                    <th>Bairro</th>
                    <td><?php echo $bairro; ?></td>
                </tr>
                <tr>
                    <th>Cidade</th>
                    <td><?php echo $cidade; ?></td>
                </tr>
                <tr>
                    <th>UF</th>
                    <td><?php echo $uf; ?></td>
                </tr>
                <tr>
                    <th>Complemento</th>
                    <td><?php echo $complemento; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>






