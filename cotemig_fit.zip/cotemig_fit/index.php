<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro de Alunos</title>
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php require ("conexao.php"); ?>
<h2 class="mb-4 center-title">Cadastro de Alunos</h2> 
  <div class="container mt-5 center-box">
    <P>cotebas finess</P>
    <!-- forms  -->
    <form action="create.php" method="post">
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="nome">Nome:</label>
          <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <div class="form-group col-md-6">
          <label for="email">E-mail:</label>
          <input type="email" class="form-control" id="email" name="email" required>
        </div>
      </div>
      <div class="form-group">
        <label for="endereco">Endereço:</label>
        <input type="text" class="form-control" id="endereco" name="endereco">
      </div>
      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="sexo">Sexo:</label>
          <select class="form-control" id="sexo" name="sexo">
            <option value="masculino">Masculino</option>
            <option value="feminino">Feminino</option>
          </select>
        </div>
        <div class="form-group col-md-4">
          <label for="numero">Número:</label>
          <input type="text" class="form-control" id="numero" name="numero">
        </div>
        <div class="form-group col-md-4">
            <label for="modalidade">Modalidade:</label>
            <select class="form-control" id="modalidade" name="modalidade">
                <option value="Natação">Natação</option>
                <option value="Pilates">Pilates</option>
                <option value="Musculação">Musculação</option>
            </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="bairro">Bairro:</label>
          <input type="text" class="form-control" id="bairro" name="bairro">
        </div>
        <div class="form-group col-md-4">
          <label for="cidade">Cidade:</label>
          <input type="text" class="form-control" id="cidade" name="cidade">
        </div>
        <div class="form-group col-md-4">
            <label for="uf">UF:</label>
                <select class="form-control" id="uf" name="uf">
                <option value="AC">Acre</option>
                <option value="AL">Alagoas</option>
                <option value="AP">Amapá</option>
                <option value="AM">Amazonas</option>
                <option value="BA">Bahia</option>
                <option value="CE">Ceará</option>
                <option value="DF">Distrito Federal</option>
                <option value="ES">Espírito Santo</option>
                <option value="GO">Goiás</option>
                <option value="MA">Maranhão</option>
                <option value="MT">Mato Grosso</option>
                <option value="MS">Mato Grosso do Sul</option>
                <option value="MG">Minas Gerais</option>
                <option value="PA">Pará</option>
                <option value="PB">Paraíba</option>
                <option value="PR">Paraná</option>
                <option value="PE">Pernambuco</option>
                <option value="PI">Piauí</option>
                <option value="RJ">Rio de Janeiro</option>
                <option value="RN">Rio Grande do Norte</option>
                <option value="RS">Rio Grande do Sul</option>
                <option value="RO">Rondônia</option>
                <option value="RR">Roraima</option>
                <option value="SC">Santa Catarina</option>
                <option value="SP">São Paulo</option>
                <option value="SE">Sergipe</option>
                <option value="TO">Tocantins</option>
                <option value="EX">Estrangeiro</option>
            </select>
        </div>
      </div>
      <div class="form-group">
        <label for="complemento">Complemento:</label>
        <input type="text" class="form-control" id="complemento" name="complemento">
      </div>
      <button type="submit" class="btn btn-primary ">Enviar</button>
      <button type="submit" class="btn btn-danger ">Limpar</button>
    </form>
  </div>
</body>
</html>