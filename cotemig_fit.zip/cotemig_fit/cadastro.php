<?php
include 'db.php';

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Receber dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    // Adicione os campos restantes aqui
    
    // Inserir os dados no banco de dados
    $sql = "INSERT INTO alunos (nome, email) VALUES ('$nome', '$email')"; // Adicione os campos restantes aqui
    
    if (mysqli_query($conn, $sql)) {
        echo "Aluno cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar aluno: " . mysqli_error($conn);
    }
}
?>